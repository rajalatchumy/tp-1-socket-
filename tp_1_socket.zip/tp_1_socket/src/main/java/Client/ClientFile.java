package Client;

import java.io.*;
import java.net.*;

public class ClientFile {
    public static void main(String[] args) {
        String serverAddress = "localhost"; // Change this to your server's IP address or hostname
        int serverPort = 5555; // Change this to the same port used by the server

        try (Socket clientSocket = new Socket(serverAddress, serverPort);
             FileInputStream fileInputStream = new FileInputStream("C://Users//aminu//IdeaProjects//tp_1_socket//src//main//java//Client//myTextFl")) {
            OutputStream outputStream = clientSocket.getOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            System.out.println("File sent to the server.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
